import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { ETLJob, PerformanceHistory, PipelineStats } from "./src/types.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // In-memory state
  let jobs: ETLJob[] = [];
  let history: PerformanceHistory[] = [];
  let warehouse: any[] = []; // Simulated Data Warehouse

  // API Routes
  app.get("/api/jobs", (req, res) => {
    res.json(jobs);
  });

  app.post("/api/jobs", (req, res) => {
    const newJob: ETLJob = {
      id: Math.random().toString(36).substring(7),
      timestamp: Date.now(),
      status: 'queued',
      progress: 0,
      ...req.body
    };
    jobs.unshift(newJob);
    if (jobs.length > 50) jobs.pop();
    res.json(newJob);
  });

  app.patch("/api/jobs/:id", (req, res) => {
    const { id } = req.params;
    const index = jobs.findIndex(j => j.id === id);
    if (index !== -1) {
      jobs[index] = { ...jobs[index], ...req.body };
      
      // If completed, record history
      if (req.body.status === 'completed' && jobs[index].metrics) {
        history.push({
          timestamp: Date.now(),
          sizeMB: jobs[index].sizeMB,
          complexity: jobs[index].complexity,
          strategy: jobs[index].strategy,
          executionTimeMs: jobs[index].metrics!.executionTimeMs,
          cost: jobs[index].metrics!.estimatedCost
        });
        if (history.length > 100) history.shift();
      }
      
      res.json(jobs[index]);
    } else {
      res.status(404).json({ error: "Job not found" });
    }
  });

  app.get("/api/stats", (req, res) => {
    const completed = history.length;
    const totalCost = history.reduce((acc, h) => acc + h.cost, 0);
    const avgLatency = completed > 0 
      ? history.reduce((acc, h) => acc + h.executionTimeMs, 0) / completed 
      : 0;
    
    const stats: PipelineStats = {
      totalProcessed: completed,
      activeJobs: jobs.filter(j => j.status !== 'completed' && j.status !== 'failed').length,
      averageLatencyMs: avgLatency,
      totalCost: totalCost,
      efficiencyScore: completed > 0 ? 85 : 0 // Simplified
    };
    res.json(stats);
  });

  app.get("/api/history", (req, res) => {
    res.json(history);
  });

  app.post("/api/warehouse", (req, res) => {
    const { data } = req.body;
    warehouse.push(...(Array.isArray(data) ? data : [data]));
    if (warehouse.length > 1000) warehouse = warehouse.slice(-1000);
    res.json({ status: "ok", count: warehouse.length });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
