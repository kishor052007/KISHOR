export type JobStatus = 'queued' | 'analyzing' | 'extracting' | 'transforming' | 'loading' | 'completed' | 'failed';

export interface ETLJob {
  id: string;
  timestamp: number;
  sourceName: string;
  dataType: 'structured' | 'unstructured';
  sizeMB: number;
  complexity: 'low' | 'medium' | 'high';
  strategy: 'lightweight' | 'distributed';
  status: JobStatus;
  progress: number;
  metrics?: {
    executionTimeMs: number;
    resourceUsage: number; // 0-100
    estimatedCost: number;
  };
  error?: string;
}

export interface PipelineStats {
  totalProcessed: number;
  activeJobs: number;
  averageLatencyMs: number;
  totalCost: number;
  efficiencyScore: number; // 0-100
}

export interface PerformanceHistory {
  timestamp: number;
  sizeMB: number;
  complexity: string;
  strategy: string;
  executionTimeMs: number;
  cost: number;
}
