import React, { useState, useEffect, useCallback } from 'react';
import { 
  Activity, 
  Database, 
  Cpu, 
  DollarSign, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  Play, 
  RefreshCw,
  BarChart3,
  Layers,
  Zap,
  ChevronRight,
  Search
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from './lib/utils';
import { ETLJob, PipelineStats, PerformanceHistory } from './types';
import { runETL } from './services/etlService';

export default function App() {
  const [jobs, setJobs] = useState<ETLJob[]>([]);
  const [stats, setStats] = useState<PipelineStats | null>(null);
  const [history, setHistory] = useState<PerformanceHistory[]>([]);
  const [isIngesting, setIsIngesting] = useState(false);
  const [activeTab, setActiveTab] = useState<'monitor' | 'history' | 'warehouse'>('monitor');

  const fetchData = useCallback(async () => {
    try {
      const [jobsRes, statsRes, historyRes] = await Promise.all([
        fetch('/api/jobs'),
        fetch('/api/stats'),
        fetch('/api/history')
      ]);
      
      const jobsData = await jobsRes.json();
      const statsData = await statsRes.json();
      const historyData = await historyRes.json();
      
      setJobs(jobsData);
      setStats(statsData);
      setHistory(historyData);
    } catch (error) {
      console.error("Failed to fetch data:", error);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 2000);
    return () => clearInterval(interval);
  }, [fetchData]);

  const handleIngest = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsIngesting(true);
    const formData = new FormData(e.currentTarget);
    const sourceName = formData.get('sourceName') as string;
    const sizeMB = Number(formData.get('sizeMB'));
    const dataType = formData.get('dataType') as 'structured' | 'unstructured';
    const rawData = formData.get('rawData') as string;

    try {
      const res = await fetch('/api/jobs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sourceName, sizeMB, dataType })
      });
      const job = await res.json();
      
      // Start the async ETL process
      runETL(job, rawData);
      
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      console.error("Ingestion failed:", error);
    } finally {
      setIsIngesting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-slate-300 font-sans selection:bg-cyan-500/30">
      {/* Header */}
      <header className="border-b border-slate-800/50 bg-[#0A0A0B]/80 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-[1600px] mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-cyan-500 rounded-lg flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
              <Zap className="w-5 h-5 text-black fill-current" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-white">EventHorizon <span className="text-cyan-500">ETL</span></h1>
              <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-medium">Autonomous Data Pipeline</p>
            </div>
          </div>

          <nav className="flex items-center gap-1 bg-slate-900/50 p-1 rounded-xl border border-slate-800/50">
            {(['monitor', 'history', 'warehouse'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={cn(
                  "px-4 py-1.5 rounded-lg text-xs font-medium transition-all capitalize",
                  activeTab === tab 
                    ? "bg-slate-800 text-cyan-400 shadow-sm" 
                    : "text-slate-500 hover:text-slate-300"
                )}
              >
                {tab}
              </button>
            ))}
          </nav>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/10 border border-green-500/20 rounded-full">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
              <span className="text-[10px] font-bold text-green-500 uppercase tracking-wider">System Online</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto p-6 grid grid-cols-12 gap-6">
        {/* Left Column: Stats & Ingest */}
        <div className="col-span-12 lg:col-span-4 space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
            <StatCard 
              label="Total Processed" 
              value={stats?.totalProcessed || 0} 
              icon={Database} 
              color="text-cyan-400"
            />
            <StatCard 
              label="Active Jobs" 
              value={stats?.activeJobs || 0} 
              icon={Activity} 
              color="text-amber-400"
            />
            <StatCard 
              label="Avg Latency" 
              value={`${Math.round(stats?.averageLatencyMs || 0)}ms`} 
              icon={Clock} 
              color="text-indigo-400"
            />
            <StatCard 
              label="Total Cost" 
              value={`$${stats?.totalCost.toFixed(2) || '0.00'}`} 
              icon={DollarSign} 
              color="text-emerald-400"
            />
          </div>

          {/* Ingest Form */}
          <section className="bg-slate-900/40 border border-slate-800/50 rounded-2xl p-6 backdrop-blur-sm">
            <div className="flex items-center gap-2 mb-6">
              <Layers className="w-5 h-5 text-cyan-500" />
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">Data Ingestion</h2>
            </div>
            
            <form onSubmit={handleIngest} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Source Name</label>
                <input 
                  name="sourceName"
                  required
                  placeholder="e.g. UserLogs_AWS_S3"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Size (MB)</label>
                  <input 
                    name="sizeMB"
                    type="number"
                    required
                    placeholder="10"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Data Type</label>
                  <select 
                    name="dataType"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors appearance-none"
                  >
                    <option value="structured">Structured</option>
                    <option value="unstructured">Unstructured</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Payload Sample</label>
                <textarea 
                  name="rawData"
                  required
                  rows={4}
                  placeholder="Paste data sample here..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500/50 transition-colors resize-none font-mono text-xs"
                />
              </div>

              <button 
                disabled={isIngesting}
                className="w-full bg-cyan-500 hover:bg-cyan-400 disabled:opacity-50 text-black font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.2)]"
              >
                {isIngesting ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
                Trigger Pipeline
              </button>
            </form>
          </section>

          {/* Performance Chart */}
          <section className="bg-slate-900/40 border border-slate-800/50 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-indigo-500" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">Latency Trends</h2>
              </div>
            </div>
            <div className="h-[200px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={history.slice(-20)}>
                  <defs>
                    <linearGradient id="colorLatency" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis dataKey="timestamp" hide />
                  <YAxis stroke="#475569" fontSize={10} axisLine={false} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '8px' }}
                    itemStyle={{ color: '#818cf8' }}
                  />
                  <Area type="monotone" dataKey="executionTimeMs" stroke="#6366f1" fillOpacity={1} fill="url(#colorLatency)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </section>
        </div>

        {/* Right Column: Active Jobs & History */}
        <div className="col-span-12 lg:col-span-8 space-y-6">
          <section className="bg-slate-900/40 border border-slate-800/50 rounded-2xl overflow-hidden flex flex-col min-h-[600px]">
            <div className="p-6 border-b border-slate-800/50 flex items-center justify-between bg-slate-900/20">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan-500" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">Pipeline Monitor</h2>
              </div>
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input 
                  placeholder="Filter jobs..."
                  className="bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-4 py-1.5 text-xs focus:outline-none focus:border-cyan-500/30 w-48"
                />
              </div>
            </div>

            <div className="flex-1 overflow-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800/50 bg-slate-900/10">
                    <th className="px-6 py-4 text-[10px] uppercase tracking-widest text-slate-500 font-bold">Job ID</th>
                    <th className="px-6 py-4 text-[10px] uppercase tracking-widest text-slate-500 font-bold">Source</th>
                    <th className="px-6 py-4 text-[10px] uppercase tracking-widest text-slate-500 font-bold">Strategy</th>
                    <th className="px-6 py-4 text-[10px] uppercase tracking-widest text-slate-500 font-bold">Status</th>
                    <th className="px-6 py-4 text-[10px] uppercase tracking-widest text-slate-500 font-bold">Progress</th>
                    <th className="px-6 py-4 text-[10px] uppercase tracking-widest text-slate-500 font-bold text-right">Metrics</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/30">
                  <AnimatePresence initial={false}>
                    {jobs.map((job) => (
                      <motion.tr 
                        key={job.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className="group hover:bg-slate-800/20 transition-colors"
                      >
                        <td className="px-6 py-4">
                          <span className="font-mono text-xs text-slate-400">#{job.id}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-sm font-medium text-slate-200">{job.sourceName}</span>
                            <span className="text-[10px] text-slate-500">{job.sizeMB}MB • {job.dataType}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          {job.strategy ? (
                            <div className={cn(
                              "inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider",
                              job.strategy === 'distributed' ? "bg-purple-500/10 text-purple-400 border border-purple-500/20" : "bg-cyan-500/10 text-cyan-400 border border-cyan-500/20"
                            )}>
                              {job.strategy === 'distributed' ? <Cpu className="w-3 h-3" /> : <Zap className="w-3 h-3" />}
                              {job.strategy}
                            </div>
                          ) : <span className="text-slate-600">—</span>}
                        </td>
                        <td className="px-6 py-4">
                          <StatusBadge status={job.status} />
                        </td>
                        <td className="px-6 py-4">
                          <div className="w-32">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-[10px] font-bold text-slate-500">{job.progress}%</span>
                            </div>
                            <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${job.progress}%` }}
                                className={cn(
                                  "h-full transition-all duration-500",
                                  job.status === 'failed' ? 'bg-red-500' : 'bg-cyan-500'
                                )}
                              />
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          {job.metrics ? (
                            <div className="flex flex-col items-end">
                              <span className="text-xs font-mono text-emerald-400">{job.metrics.executionTimeMs}ms</span>
                              <span className="text-[10px] text-slate-500">${job.metrics.estimatedCost.toFixed(3)}</span>
                            </div>
                          ) : <span className="text-slate-600">—</span>}
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
              {jobs.length === 0 && (
                <div className="flex flex-col items-center justify-center py-20 text-slate-600">
                  <Database className="w-12 h-12 mb-4 opacity-20" />
                  <p className="text-sm">No active pipeline operations</p>
                </div>
              )}
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}

function StatCard({ label, value, icon: Icon, color }: { label: string, value: string | number, icon: any, color: string }) {
  return (
    <div className="bg-slate-900/40 border border-slate-800/50 rounded-2xl p-5 backdrop-blur-sm group hover:border-slate-700 transition-colors">
      <div className="flex items-center justify-between mb-3">
        <div className={cn("p-2 rounded-xl bg-slate-950 border border-slate-800", color)}>
          <Icon className="w-4 h-4" />
        </div>
        <ChevronRight className="w-3 h-3 text-slate-700 group-hover:text-slate-500 transition-colors" />
      </div>
      <p className="text-[10px] uppercase tracking-[0.2em] text-slate-500 font-bold mb-1">{label}</p>
      <p className="text-xl font-bold text-white tracking-tight">{value}</p>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const configs: Record<string, { label: string, color: string, icon: any }> = {
    queued: { label: 'Queued', color: 'text-slate-400 bg-slate-400/10 border-slate-400/20', icon: Clock },
    analyzing: { label: 'Analyzing', color: 'text-indigo-400 bg-indigo-400/10 border-indigo-400/20', icon: Search },
    extracting: { label: 'Extracting', color: 'text-blue-400 bg-blue-400/10 border-blue-400/20', icon: Layers },
    transforming: { label: 'Transforming', color: 'text-cyan-400 bg-cyan-400/10 border-cyan-400/20', icon: RefreshCw },
    loading: { label: 'Loading', color: 'text-amber-400 bg-amber-400/10 border-amber-400/20', icon: Database },
    completed: { label: 'Completed', color: 'text-emerald-400 bg-emerald-400/10 border-emerald-400/20', icon: CheckCircle2 },
    failed: { label: 'Failed', color: 'text-red-400 bg-red-400/10 border-red-400/20', icon: AlertCircle },
  };

  const config = configs[status] || configs.queued;
  const Icon = config.icon;

  return (
    <div className={cn(
      "inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider border",
      config.color
    )}>
      <Icon className={cn("w-3 h-3", status === 'transforming' || status === 'analyzing' ? 'animate-spin' : '')} />
      {config.label}
    </div>
  );
}
