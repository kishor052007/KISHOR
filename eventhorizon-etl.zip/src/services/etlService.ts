import { GoogleGenAI } from "@google/genai";
import { ETLJob } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function analyzeData(dataSample: string, sizeMB: number): Promise<{ complexity: 'low' | 'medium' | 'high', strategy: 'lightweight' | 'distributed' }> {
  try {
    // Fetch recent history for self-tuning context
    const historyRes = await fetch('/api/history');
    const history = await historyRes.json();
    const recentHistory = history.slice(-5);

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this data sample for ETL processing. 
      Data Sample: ${dataSample.substring(0, 1000)}
      Total Size: ${sizeMB} MB
      
      Historical Performance (Self-Tuning Context):
      ${JSON.stringify(recentHistory)}

      Based on the data sample, size, and past performance, determine the complexity (low, medium, high) and the best processing strategy (lightweight, distributed) to minimize cost while meeting performance targets.
      Return JSON format: { "complexity": "...", "strategy": "..." }`,
      config: {
        responseMimeType: "application/json"
      }
    });

    const result = JSON.parse(response.text);
    return result;
  } catch (error) {
    console.error("Analysis failed:", error);
    // Fallback heuristic
    return {
      complexity: sizeMB > 100 ? 'high' : 'low',
      strategy: sizeMB > 50 ? 'distributed' : 'lightweight'
    };
  }
}

export async function transformData(data: string, complexity: string): Promise<any[]> {
  // Simulate heavy processing for high complexity
  if (complexity === 'high') {
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Transform and clean this data for a data warehouse. 
      Data: ${data.substring(0, 2000)}
      
      Extract key entities and return a clean JSON array of objects.`,
      config: {
        responseMimeType: "application/json"
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("Transformation failed:", error);
    return [{ raw: data, processed: false, error: "Transformation failed" }];
  }
}

export async function runETL(job: ETLJob, rawData: string) {
  const startTime = Date.now();
  
  try {
    // 1. Analyze
    await updateJob(job.id, { status: 'analyzing', progress: 10 });
    const { complexity, strategy } = await analyzeData(rawData, job.sizeMB);
    await updateJob(job.id, { complexity, strategy, progress: 30 });

    // 2. Extract
    await updateJob(job.id, { status: 'extracting', progress: 50 });
    await new Promise(resolve => setTimeout(resolve, 500)); // Simulate extraction

    // 3. Transform
    await updateJob(job.id, { status: 'transforming', progress: 70 });
    const transformedData = await transformData(rawData, complexity);

    // 4. Load
    await updateJob(job.id, { status: 'loading', progress: 90 });
    await fetch('/api/warehouse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ data: transformedData })
    });

    // 5. Complete
    const endTime = Date.now();
    const executionTimeMs = endTime - startTime;
    const resourceUsage = strategy === 'distributed' ? 80 : 20;
    const estimatedCost = (executionTimeMs / 1000) * (strategy === 'distributed' ? 0.05 : 0.01);

    await updateJob(job.id, {
      status: 'completed',
      progress: 100,
      metrics: {
        executionTimeMs,
        resourceUsage,
        estimatedCost
      }
    });

  } catch (error) {
    console.error("ETL Pipeline Error:", error);
    await updateJob(job.id, { status: 'failed', error: String(error) });
  }
}

async function updateJob(id: string, updates: Partial<ETLJob>) {
  await fetch(`/api/jobs/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
}
